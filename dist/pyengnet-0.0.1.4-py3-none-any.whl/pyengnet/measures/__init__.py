from .Kendall import Kendall
from .NMI import NMI
from .Spearman import Spearman